class Car

	attr_accessor :tank_size, :make, :model, :mpg
	attr_reader :distance

	PRICE_OF_GAS = 2.34
	AVG_MAINTENANCE_COST = 0.61

	def initialize(make, model, mpg, tank_size)
		@make = make
		@model = model
		@mpg = mpg
		@tank_size = tank_size
		@distance = 0
	end

	def drive(distance)
		@distance += distance
	end

	def reset_odometer()
		@distance = 0
	end

	def gas_cost()
		distance / mpg * PRICE_OF_GAS
	end

	def maintenance_cost()
		AVG_MAINTENANCE_COST * distance
	end

	def total_cost()
		gas_cost + maintenance_cost
	end

	def number_of_fillups()
		(distance / tank_size * mpg).ceil
	end

end