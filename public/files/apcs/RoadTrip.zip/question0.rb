require './Car'
require './Trip'

car = Car.new("Ford", "Mustang", 30, 15.5)
trip = Trip.new("Denver", "Los Angeles", 1016)
trip2 = Trip.new("Denver", "New York", 1778)
puts "Gas Cost is #{trip.gas_cost(car)}"
puts "Gas Cost is #{trip2.gas_cost(car)}"