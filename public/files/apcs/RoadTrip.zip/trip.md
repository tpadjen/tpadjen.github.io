Denver -> New York           1778 miles
Denver -> Los Angeles        1016 miles
Denver -> Phoenix             821 miles
Denver -> Las Vegas           749 miles
Phoenix -> Las Vegas          298 miles
Phoenix -> Los Angeles        310 miles
Las Vegas -> Los Angeles      270 miles
Las Vegas -> San Francisco    568 miles
Los Angeles -> San Francisco  382 miles

Make 		Model				MPG			Tank Size (gal)
-----------------------------------------------------------
Toyota 		Corolla				40			13.2
Honda 		Civic				42			12.4
Ford		Mustang				30			15.5
Nissan		Rogue				33          14.5
Chevrolet	Malibu              36			15.8
Jeep		Grand Cherokee		26			24.6

Avg US Gas Price October 2017 = $2.34/gal
Avg driving maintenance cost  = $0.61/mile 
