class Trip

	attr_reader :start, :destination, :distance

	def initialize(start, destination, distance)
		@start = start
		@destination = destination
		@distance = distance
	end

	def gas_cost(car)
		car.reset_odometer
		car.drive(distance)
		return car.gas_cost
	end

end