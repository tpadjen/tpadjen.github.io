With a partner, create a class to model a Car. Your car class will be used in a program to estimate trip costs.

Questions:

0) What would be the price of gas on a trip from Denver to LA in a Mustang?
1) How many times would a Grand Cherokee have to be filled up on a trip from Denver to New York?
2) What is the estimated total cost for each car on a trip with the following  itinerary?

	a. Start in Denver
	b. Gamble in Vegas
	c. See the Golden Gate Bridge
	d. Walk along the Venice Beach boardwalk
	e. Catch a spring training game outside of Phoenix
	f. Go home